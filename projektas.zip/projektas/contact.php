<?php
    require __DIR__ . '../app/app.php';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="spa and beauty center">
        <meta name="keywords" content="leospa, spa, beauty, massage, reflexology">
        <title>Leospa</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/about.css">
    <link rel="stylesheet" href="CSS/service.css">
    <link rel="stylesheet" href="CSS/contact.css">
    <script src="https://kit.fontawesome.com/a41f69d5b0.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display|Roboto:300,400,500|Rufina:400,700&display=swap" rel="stylesheet">
    </head>

    <body>
        <main>
            
              <div class="navbar navbar-default navbar-static-top">
            <div class="container-header"> 
                <div class="navbar-header">
                    <div class="logo-header">
                    <a href="index.php"><img src="images/main_logo.png" alt="Logo of Leospa" width="60" height="50"></a>
                    <div class="logo-title"><a href="index.php">Leospa</a></div>
                </div>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class='sr-only'>Toggle navigation </span> 
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                    </button>
                </div>
                    <ul class="nav navbar-nav navbar-right collapse navbar-collapse">
                        <li><a href="index.php">home</a></li>
                        <li><a href="about.php">about</a></li>
                        <li><a href="features.php">feature</a></li>
                        <li><a href="service.php">service</a></li>
                        <li><a href="contact.php">contact</a></li>
                    </ul>  
                </div>
            </div>
            
            <div class="contact-info">
                <div class="contact-top">
                    <h1>Get In Touch</h1>
                    <p>To doesn't his appear replenish together called he of mad place won't wherein blessed second every wherein were meat kind wherein and martcin.</p>
                </div>
                <div class="contact-content">
                    <div class="contact-info">
                        <div class="first">
                            <i class="fas fa-map-marked-alt circle-icon"></i>
                            <p>848 E 28th ST, BROOKLYN <br> NEW YORK, USA </p>
                        </div>
                        <div class="second">
                            <i class="far fa-envelope circle-icon"></i>
                            <a href="mailto:example@leospa.com">example@leospa.com <br>example@leospa.com</a>                        
                        </div>
                        <div class="third">
                            <i class="fas fa-mobile-alt circle-icon"></i>
                            <a href="tel: +02 365 2365 3265 (02)"> tel: +02 365 2365 3265 (02) <br>+01 365 2365 3265 (04)</a> 
                        </div>
                    </div>
                    <div class="contactForm">
                        <form id="forma" action="contact.php" method="post">
                            <p><input type="text" name="vardas" placeholder="Name" required></p>
                            <p><input type="email" name="email" placeholder="Email Address" required></p>
                            <p><textarea placeholder="Write Comment" name="message" required></textarea></p>
                            <p><button name="submit" type="submit" id="contact-submit">submit now</button></p>
                        </form> 
                    </div>
                </div>
            </div>
            
            <div class="footer">
                <div class="logo-footer">
                    <a href="index.php"><img src="images/main_logo.png" alt="Logo of Leospa" width="50" height="40"></a>
                </div>
                <div class="logo-title"><a href="index.php">Leospa</a></div> 
                <div class="footer-navigation">
                    <div class="home"><a href="index.php">HOME</a></div>
                    <div class="about"><a href="about.php">ABOUT</a></div>
                    <div class="feature"><a href="features.php">FEATURE</a></div>
                    <div class="service"><a href="service.php">SERVICE</a></div>
                    <div class="contact"><a href="contact.php">CONTACT</a></div>
                </div>
                <div class="social-networks">
                    <a href="#top"><i class="fab fa-facebook-f"></i></a>&#124;
                    <a href="#top"><i class="fab fa-twitter"></i></a>&#124;
                    <a href="#top"><i class="fab fa-vimeo-v"></i></a>&#124;
                    <a href="#top"><i class="fab fa-instagram"></i></a>&#124;
                </div>
                <div id="copyright">
                    <?= '&copy; COPYRIGHT ' .date('Y'). ' ' .'THEMEIES.COM. ALL RIGHTS RESERVED.'; ?>
                </div>
            </div>
        </main>
    <script src="JS/jquery-3.2.1.min.js"></script>
    <script src="JS/custom.js"></script>
    </body>
</html>