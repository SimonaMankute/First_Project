<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="spa and beauty center">
        <meta name="keywords" content="leospa, spa, beauty, massage, reflexology">
        <title>Leospa</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="CSS/about.css">
        <link rel="stylesheet" href="CSS/style.css">
        <script src="https://kit.fontawesome.com/a41f69d5b0.js" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Playfair+Display:ital,wght@1,700|Roboto:300,400,500|Rufina:400,700&display=swap" rel="stylesheet">
    </head>

    <body>
        <main>
            
             <div class="navbar navbar-default navbar-static-top">
            <div class="container-header"> 
                <div class="navbar-header">
                    <div class="logo-header">
                    <a href="index.php"><img src="images/main_logo.png" alt="Logo of Leospa" width="60" height="50"></a>
                    <div class="logo-title"><a href="index.php">Leospa</a></div>
                </div>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class='sr-only'>Toggle navigation </span> 
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                    </button>
                </div>
                    <ul class="nav navbar-nav navbar-right collapse navbar-collapse">
                        <li><a href="index.php">home</a></li>
                        <li><a href="about.php">about</a></li>
                        <li><a href="features.php">feature</a></li>
                        <li><a href="service.php">service</a></li>
                        <li><a href="contact.php">contact</a></li>
                    </ul>  
                </div>
            </div>
            
            <div class="about-us">
                <img src="images/main_logo.png" alt="Logo of Leospa" width="70" height="60">
                <h2>ABOUT OUR SPA CENTER</h2>
                <h3>Come and you will be inspired!</h3>
                <div id="about-us-text">
                    <p>Drawing both on ancient philosophies and contemporary thinking, we offer a range of treatments designed to optimize your emotional, physical and mental well-being. The therapeutic and health benefits of spas are vast. The combination of heat, massage and buoyancy means the physical and mental benefits of relaxing in a spa are enormous. You can reduce stress and anxiety, ease tired and stiff muscles and enjoy full-body relaxation.
                    </p>
                    <a href="service.php"><button type="button">OUR PROCEDURES</button></a>
                </div>
            </div>
            
            <div class="team">
                <div class="inside_team">
                    <div class="team-heading">
                        <h1>Experienced Team</h1>
                        <p>Our experienced team collaborates closely with you throughout our engagement. We take great pride in our work and strive for consistent excellence.</p>
                    </div>
                    <div class="team_content">
                        <div class="team_members">
                            <div class="team1">
                                <img src="images/joseph.png" alt="Josephine Austin" height="400" width="380">
                                <div class="caption">
                                    <h3>Josephine Austin</h3>
                                    <p>Thai Massage</p>
                                    <span class="top-content"></span>
                                    <span class="bottom-content">
                                         <ul>
                                            <a href="about.php"><li><i class="fab fa-facebook-f"></i></li></a>
                                            <a href="about.php"><li><i class="fab fa-twitter"></i></li></a>
                                            <a href="about.php"><li><i class="fab fa-google-plus-g"></i></li></a>
                                            <a href="about.php"><li><i class="fab fa-instagram"></i></li></a>
                                        </ul>
                                    </span>
                                </div>
                            </div>
                            <div class="team1">
                                <img src="images/david.png" alt="Daniella Hannan" height="400" width="380">
                                <div class="caption">
                                    <h3>Daniella Hannan</h3>
                                    <p>Thai Massage</p>
                                    <span class="top-content"></span>
                                    <span class="bottom-content">
                                    <ul>
                                        <a href="about.php"><li><i class="fab fa-facebook-f"></i></li></a>
                                        <a href="about.php"><li><i class="fab fa-twitter"></i></li></a>
                                        <a href="about.php"><li><i class="fab fa-google-plus-g"></i></li></a>
                                        <a href="about.php"><li><i class="fab fa-instagram"></i></li></a>
                                    </ul>
                                    </span>
                                </div>
                            </div>
                            <div class="team1">
                                <img src="images/cheryl.png" alt="Cheryl Harris" height="400" width="380">
                                <div class="caption">
                                    <h3>Cheryl Harris</h3>
                                    <p>Thai Massage</p>
                                    <span class="top-content"></span>
                                    <span class="bottom-content">
                                    <ul>
                                        <a href="about.php"><li><i class="fab fa-facebook-f"></i></li></a>
                                        <a href="about.php"><li><i class="fab fa-twitter"></i></li></a>
                                        <a href="about.php"><li><i class="fab fa-google-plus-g"></i></li></a>
                                        <a href="about.php"><li><i class="fab fa-instagram"></i></li></a>
                                    </ul>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>           
                  </div>
            </div>
            
            <div class="slideshow-container">
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel" data-slide-to="1"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="item active">
                            <h1>&quot;</h1>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                            <div id="testPic">
                            <img src="images/jack_marsh.png" alt="Jackie Marsh">
                            <p><span>Jackie Marsh</span>, Executive</p>
                            </div>
                        </div>
                        <div class="item">
                            <h1>&quot;</h1>
                            <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <div id="testPic">
                            <img src="images/man-smiling_1194-11653.jpg" alt="Bob Sparks">
                            <p><span>Bob Sparks</span>, CEO</p>
                            </div>
                        </div>
                    </div>
                </div>    
            </div>
            
            
            <div class="footer">
                <div class="logo-footer">
                    <a href="index.php"><img src="images/main_logo.png" alt="Logo of Leospa" width="50" height="40"></a>
                </div>
                <div class="logo-title"><a href="index.php">Leospa</a></div> 
                <div class="footer-navigation">
                    <div class="home"><a href="index.php">HOME</a></div>
                    <div class="about"><a href="about.php">ABOUT</a></div>
                    <div class="feature"><a href="features.php">FEATURE</a></div>
                    <div class="service"><a href="service.php">SERVICE</a></div>
                    <div class="contact"><a href="contact.php">CONTACT</a></div>
                </div>
                <div class="social-networks">
                    <a href="#top"><i class="fab fa-facebook-f"></i></a>&#124;
                    <a href="#top"><i class="fab fa-twitter"></i></a>&#124;
                    <a href="#top"><i class="fab fa-vimeo-v"></i></a>&#124;
                    <a href="#top"><i class="fab fa-instagram"></i></a>&#124;
                </div>
                <div id="copyright">
                    <?= '&copy; COPYRIGHT ' .date('Y'). ' ' .'THEMEIES.COM. ALL RIGHTS RESERVED.'; ?>
                </div>
            </div>
        </main>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </body>
</html>