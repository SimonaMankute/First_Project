<?php
    if(isset($_POST['submit'])) {
        $name = trim($_POST['name']);
        $email= trim($_POST['email']);
        $serviceSelect= trim($_POST['serviceSelect']);
        $phone= trim($_POST['phone']);
        $date= trim($_POST['date']);
        $time= trim($_POST['time']);
        $message = trim($_POST['message']);
  

        if(!empty($name) && !empty($email) && !empty($serviceSelect) && !empty($phone)) {
            if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $from="$email";
                $to="simona.mankute@yahoo.com";
                $subject= "Reservation";
                $autorius= 'From: ' . $name . ', ' . $email;
                $zinute=htmlspecialchars($message);
                mail($to, $subject, $autorius, $zinute, $from);
                echo "<script>alert('Thank you for your reservation.'); </script>";
            }
        }

        include('dbServices.php');   
    }
        

?>