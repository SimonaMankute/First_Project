<?php
    define("DB_SERVER", "localhost");
    define("DB_USER", "root");
    define("DB_PASSWORD", "");
    define("DB_NAME", "projektas");

    $mysqli = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);
    if($mysqli->connect_error) {
        echo "We appologize. An error has occured. \n";
        echo 'Error: ' . $mysqli->connect_error . '\n';
        exit();
    }
    
   mysqli_query($mysqli, "INSERT INTO rezervacija (name, email, service, phone, date, time, message) 
   VALUES('$_POST[name]', '$_POST[email]', '$_POST[serviceSelect]', '$_POST[phone]', '$_POST[date]', '$_POST[time]', '$_POST[message]')");

?>