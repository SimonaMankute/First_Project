<?php
        require __DIR__ . '../app/app.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="spa and beauty center">
    <meta name="keywords" content="leospa, spa, beauty, massage, reflexology">
    <title>Leospa</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/about.css">
    <link rel="stylesheet" href="CSS/service.css">
    <link rel="stylesheet" href="CSS/contact.css">
    <script src="https://kit.fontawesome.com/a41f69d5b0.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display|Roboto:300,400,500|Rufina:400,700&display=swap" rel="stylesheet">
   
</head>

<body>
     <main>   
         <div class="navbar navbar-default navbar-static-top">
            <div class="container-header"> 
                <div class="navbar-header">
                    <div class="logo-header">
                    <a href="index.php"><img src="images/main_logo.png" alt="Logo of Leospa" width="60" height="50"></a>
                    <div class="logo-title"><a href="index.php">Leospa</a></div>
                </div>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class='sr-only'>Toggle navigation </span> 
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                    </button>
                </div>
                    <ul class="nav navbar-nav navbar-right collapse navbar-collapse">
                        <li><a href="index.php">home</a></li>
                        <li><a href="about.php">about</a></li>
                        <li><a href="features.php">feature</a></li>
                        <li><a href="service.php">service</a></li>
                        <li><a href="contact.php">contact</a></li>
                    </ul>  
                </div>
            </div>
        
           
        
        <div class="intro">
            <div class="flower-top">
                <img src="images/flowers_top.png" alt="palm-flowers picture" height="90%" width="auto">
            </div>
            <div class="intro-text">
                <h3 style="color:#ff817e">spa & beauty center</h3>
                <h1>Beauty and success <br> starts here.</h1>
                <p>Relax, unwind and escape with our selection of SPA breaks. <br> There's a perfect SPA experience for everyone!</p>
                    <div class="reserve-watch">
                        <a href="#appforma"><button type="button">Reserve now!</button></a>
                    <div class="watch"> 
                        <a href="#videostory" class="button more" id="videolink"><i class="far fa-play-circle" aria-hidden="true" style="font-size: 1.3em; padding-right: 20px;"></i>Watch our story</a>
                        <div id="videostory" class="mfp-hide">
                            <iframe width="950" height="580" src="https://www.youtube.com/embed/QWUPm0ND7HY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        
                    </div>   
                    </div>
                    
            </div> 
            <div class="side-photo">
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel" data-slide-to="1"></li>
                        <li data-target="#myCarousel" data-slide-to="2"></li>
                        <li data-target="#myCarousel" data-slide-to="3"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="item active">
                            <img src="images/body_treatment.jpg" alt="Body treatment" height="640" width="400">
                        </div>
                        <div class="item">
                            <img src="images/body_treatment_2.jpg" alt="Body treatment" height="640" width="400">
                        </div>
                        <div class="item">
                            <img src="images/body_treatment_3.jpg" alt="Body treatment" height="640" width="400">
                        </div>
                        <div class="item">
                            <img src="images/body_treatment_4.jpg" alt="Body treatment" height="640" width="400">
                        </div>
                    </div>
                </div>    
            </div>
        </div>
        
    
         
        <div class="about-us">
            <img src="images/main_logo.png" alt="Logo of Leospa" width="70" height="60">
            <h2>ABOUT OUR SPA CENTER</h2>
            <h3>Come and you will be inspired!</h3>
            <div id="about-us-text">
                <p>Drawing both on ancient philosophies and contemporary thinking, we offer a range of treatments designed to optimize your emotional, physical and mental well-being.The therapeutic and health benefits of spas are vast. The combination of heat, massage and buoyancy means the physical and mental benefits of relaxing in a spa are enormous. You can reduce stress and anxiety, ease tired and stiff muscles and enjoy full-body relaxation.
                </p>
            </div>
            <a href="about.php"><button type="button">READ MORE</button></a>
        </div> 
        
        <div class="treatment">
            <div class="picture1">
                <img src="images/body_treatment.jpg" height="440" width="380" alt="Body treatment">
                <span class="image-overlay"><i class="fas fa-spa" style="font-size:40px;"></i><br>Body Treatment</span>
            </div>
            <div class="picture1">
                <img src="images/body_treatment_2.jpg" height="440" width="380" alt="Body treatment">
                <span class="image-overlay"><i class="fas fa-spa" style="font-size:40px;"></i><br>Body Treatment</span>
            </div>
            <div class="picture1">
                <img src="images/body_treatment_3.jpg" height="440" width="380" alt="Body treatment">
                <span class="image-overlay"><i class="fas fa-spa" style="font-size:40px;"></i><br>Body Treatment</span>
            </div>
            <div class="picture1">
                <img src="images/body_treatment_4.jpg" height="440" width="380" alt="Body treatment">
                <span class="image-overlay"><i class="fas fa-spa" style="font-size:40px;"></i><br>Body Treatment</span>
            </div>    
         </div>
         
         <div class="services">
         <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Popular Procedures</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p>The basic spa treatments are massage, facial, body treatment, manicure, and pedicure. A massage will help you relax and get rid of muscle tension. (A Swedish massage is a good place for beginners.) A facial is a deep cleansing of your face, and a body treatment exfoliates and softens the skin on your body.</p>
                </div>
            </div>
            <div class="row features">
                <div class="col-lg-4 text-center">
                    <div class="box">
                        <img src="images/massage_therapy.jpg" alt="Massage Therapy" height="230" width="280">
                        <h2>Massage Therapy</h2>
                        <p>Massage is delivered to improve the flow of blood and lymph (fluid in lymph glands, part of immune system), to reduce muscular tension or flaccidity, to affect the nervous system through stimulation or sedation, and to enhance tissue healing.</p>
                        <a href="service.php"><button type="button">READ MORE</button></a>
                    </div>
                </div>
                <div class="col-lg-4 text-center">
                    <div class="box">
                        <img src="images/beauty_care.jpg" alt="Beauty Care" height="230" width="280">
                        <h2>Beauty Care</h2>
                        <p>Beaty care is delivered to improve the flow of blood and lymph (fluid in lymph glands, part of immune system), to reduce muscular tension or flaccidity, to affect the nervous system through stimulation or sedation, and to enhance tissue healing.</p>
                        <a href="service.php"><button type="button">READ MORE</button></a>
                    </div>
                </div>
                <div class="col-lg-4 text-center">
                    <div class="box">
                        <img src="images/reflexology.jpg" alt="Reflexology" height="230" width="280">
                        <h2>Executive Reflexology</h2>
                        <p>Reflexology is delivered to improve the flow of blood and lymph (fluid in lymph glands, part of immune system), to reduce muscular tension or flaccidity, to affect the nervous system through stimulation or sedation, and to enhance tissue healing.</p>
                        <a href="service.php"><button type="button">READ MORE</button></a>
                    </div>
                </div>
            </div>
        </div>
        </div>
        
        <div class="slideshow-container">
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel" data-slide-to="1"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="item active">
                            <h1>&quot;</h1>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                            <div id="testPic">
                            <img src="images/jack_marsh.png" alt="Jackie Marsh">
                            <p><span>Jackie Marsh</span>, Executive</p>
                            </div>
                        </div>
                        <div class="item">
                            <h1>&quot;</h1>
                            <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                            <div id="testPic">
                            <img src="images/man-smiling_1194-11653.jpg" alt="Bob Sparks">
                            <p><span>Bob Sparks</span>, CEO</p>
                            </div>
                        </div>
                    </div>
                </div>    
            </div>
         
         <div class="team">
                <div class="inside_team">
                    <div class="team-heading">
                        <h1>Experienced Team</h1>
                        <p>Our experienced team collaborates closely with you throughout our engagement. We take great pride in our work and strive for consistent excellence.</p>
                    </div>
                    <div class="team_content">
                        <div class="team_members">
                            <div class="team1">
                                <img src="images/joseph.png" alt="Josephine Austin" height="400" width="380">
                                <div class="caption">
                                    <h3>Josephine Austin</h3>
                                    <p>Thai Massage</p>
                                    <span class="top-content"></span>
                                    <span class="bottom-content">
                                         <ul>
                                            <a href="about.php"><li><i class="fab fa-facebook-f"></i></li></a>
                                            <a href="about.php"><li><i class="fab fa-twitter"></i></li></a>
                                            <a href="about.php"><li><i class="fab fa-google-plus-g"></i></li></a>
                                            <a href="about.php"><li><i class="fab fa-instagram"></i></li></a>
                                        </ul>
                                    </span>
                                </div>
                            </div>
                            <div class="team1">
                                <img src="images/david.png" alt="Daniella Hannan" height="400" width="380">
                                <div class="caption">
                                    <h3>Daniella Hannan</h3>
                                    <p>Thai Massage</p>
                                    <span class="top-content"></span>
                                    <span class="bottom-content">
                                    <ul>
                                        <a href="about.php"><li><i class="fab fa-facebook-f"></i></li></a>
                                        <a href="about.php"><li><i class="fab fa-twitter"></i></li></a>
                                        <a href="about.php"><li><i class="fab fa-google-plus-g"></i></li></a>
                                        <a href="about.php"><li><i class="fab fa-instagram"></i></li></a>
                                    </ul>
                                    </span>
                                </div>
                            </div>
                            <div class="team1">
                                <img src="images/cheryl.png" alt="Cheryl Harris" height="400" width="380">
                                <div class="caption">
                                    <h3>Cheryl Harris</h3>
                                    <p>Thai Massage</p>
                                    <span class="top-content"></span>
                                    <span class="bottom-content">
                                    <ul>
                                        <a href="about.php"><li><i class="fab fa-facebook-f"></i></li></a>
                                        <a href="about.php"><li><i class="fab fa-twitter"></i></li></a>
                                        <a href="about.php"><li><i class="fab fa-google-plus-g"></i></li></a>
                                        <a href="about.php"><li><i class="fab fa-instagram"></i></li></a>
                                    </ul>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>           
                  </div>
            </div>
         
         <div class="appointment">
                <div id="appPic">
                    <img src="images/appointment.jpg" alt="Appointment" height="500" width="545">
                </div>
                <div class="appointmentForm">
                        <form id="appforma" action="index.php" method="post">
                            <div class="twoColumns">
                                <div class="one">
                                    <p><input type="text" name="name" placeholder="NAME" required></p>
                                    <p><select id="serviceSelect">
                                        <option value="mainService">SELECT SERVICE</option>
                                        <option value="firstService">Service1</option>
                                        <option value="secondService">Service2</option>
                                        <option value="thirdService">Service3</option>
                                    </select></p>
                                    <p><input type="date" name="date" required></p>
                                </div>
                                <div class="two">
                                    <p><input type="email" name="email" placeholder="EMAIL ADDRESS" required></p>
                                    <p><input type="text" name="phone" placeholder="PHONE NUMBER" required></p>
                                    <p><input type="time" name="time" required></p>
                                </div>
                            </div>
                            <div class="notes">
                                <p><textarea placeholder="YOUR NOTES" name="message"></textarea></p>
                                <p><button name="submit" type="submit" id="appointment-submit">MAKE AN APPOINTMENT</button></p>
                            </div>
                        </form> 
                </div>
            </div>
         
         <div class="services" style="margin: 0;">
            <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1>Latest From Blog</h1>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 text-center">
                            <p>To doesn't his appear replenish together called he of mad place won't wherein blessed second every wherein were meat kind wherein and martcin.</p>
                        </div>
                    </div>
                    <div class="row features">
                        <div class="col-lg-4 text-center">
                            <div class="box">
                                <img src="images/massage_therapy.jpg" alt="Massage Therapy" height="230" width="280">
                                <h2>Massage Therapy</h2>
                                <p>Massage is delivered to improve the flow of blood and lymph (fluid in lymph glands, part of immune system), to reduce muscular tension or flaccidity, to affect the nervous system through stimulation or sedation, and to enhance tissue healing.</p>
                                <a href="features.php"><button type="button">READ MORE</button></a>
                            </div>
                        </div>
                        <div class="col-lg-4 text-center">
                            <div class="box">
                                <img src="images/beauty_care.jpg" alt="Beauty Care" height="230" width="280">
                                <h2>Beauty Care</h2>
                                <p>Beaty care is delivered to improve the flow of blood and lymph (fluid in lymph glands, part of immune system), to reduce muscular tension or flaccidity, to affect the nervous system through stimulation or sedation, and to enhance tissue healing.</p>
                                <a href="features.php"><button type="button">READ MORE</button></a>
                            </div>
                        </div>
                        <div class="col-lg-4 text-center">
                            <div class="box">
                                <img src="images/reflexology.jpg" alt="Reflexology" height="230" width="280">
                                <h2>Executive Reflexology</h2>
                                <p>Reflexology is delivered to improve the flow of blood and lymph (fluid in lymph glands, part of immune system), to reduce muscular tension or flaccidity, to affect the nervous system through stimulation or sedation, and to enhance tissue healing.</p>
                                <a href="features.php"><button type="button">READ MORE</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
         
         
         <div class="contact-info">
                <div class="contact-top">
                    <h1>Get In Touch</h1>
                    <p>To doesn't his appear replenish together called he of mad place won't wherein blessed second every wherein were meat kind wherein and martcin.</p>
                </div>
                <div class="contact-content">
                    <div class="contact-info">
                        <div class="first">
                            <i class="fas fa-map-marked-alt circle-icon"></i>
                            <p>848 E 28th ST, BROOKLYN <br> NEW YORK, USA </p>
                        </div>
                        <div class="second">
                            <i class="far fa-envelope circle-icon"></i>
                            <a href="mailto:example@leospa.com">example@leospa.com <br>example@leospa.com</a>                        
                        </div>
                        <div class="third">
                            <i class="fas fa-mobile-alt circle-icon"></i>
                            <a href="tel: +02 365 2365 3265 (02)"> tel: +02 365 2365 3265 (02) <br>+01 365 2365 3265 (04)</a> 
                        </div>
                    </div>
                    <div class="contactForm">
                        <form id="forma" action="index.php" method="post">
                            <p><input type="text" name="vardas" placeholder="Name" required></p>
                            <p><input type="email" name="email" placeholder="Email Address" required></p>
                            <p><textarea placeholder="Write Comment" name="message" required></textarea></p>
                            <p><button name="submit" type="submit" id="contact-submit">submit now</button></p>
                        </form> 
                    </div>
                </div>
            </div>

     
        <div class="footer">
            <div class="logo-footer">
                <a href="index.php"><img src="images/main_logo.png" alt="Logo of Leospa" width="50" height="40"></a>
            </div>
            <div class="logo-title"><a href="index.php">Leospa</a></div> 
            <div class="footer-navigation">
                <div class="home"><a href="index.php">HOME</a></div>
                <div class="about"><a href="about.php">ABOUT</a></div>
                <div class="feature"><a href="features.php">FEATURE</a></div>
                <div class="service"><a href="service.php">SERVICE</a></div>
                <div class="contact"><a href="contact.php">CONTACT</a></div>
            </div>
            <div class="social-networks">
                <a href="#top"><i class="fab fa-facebook-f"></i></a>&#124;
                <a href="#top"><i class="fab fa-twitter"></i></a>&#124;
                <a href="#top"><i class="fab fa-vimeo-v"></i></a>&#124;
                <a href="#top"><i class="fab fa-instagram"></i></a>&#124;
            </div>
            <div id="copyright">
                <?= '&copy; COPYRIGHT ' .date('Y'). ' ' .'THEMEIES.COM. ALL RIGHTS RESERVED.'; ?>
            </div>
         </div>
    
    </main>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="JS/custom.js"></script>
</body>
</html>
