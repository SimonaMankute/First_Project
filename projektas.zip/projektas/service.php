<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="spa and beauty center">
        <meta name="keywords" content="leospa, spa, beauty, massage, reflexology">
        <title>Leospa</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/about.css">
    <link rel="stylesheet" href="CSS/service.css">
    <link rel="stylesheet" href="CSS/contact.css">
    <script src="https://kit.fontawesome.com/a41f69d5b0.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display|Roboto:300,400,500|Rufina:400,700&display=swap" rel="stylesheet">
    </head>

    <body>
        <main>
            
               <div class="navbar navbar-default navbar-static-top">
            <div class="container-header"> 
                <div class="navbar-header">
                    <div class="logo-header">
                    <a href="index.php"><img src="images/main_logo.png" alt="Logo of Leospa" width="60" height="50"></a>
                    <div class="logo-title"><a href="index.php">Leospa</a></div>
                </div>
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class='sr-only'>Toggle navigation </span> 
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                        <span class='icon-bar'></span>
                    </button>
                </div>
                    <ul class="nav navbar-nav navbar-right collapse navbar-collapse">
                        <li><a href="index.php">home</a></li>
                        <li><a href="about.php">about</a></li>
                        <li><a href="features.php">feature</a></li>
                        <li><a href="service.php">service</a></li>
                        <li><a href="contact.php">contact</a></li>
                    </ul>  
                </div>
            </div>
            
            <div class="services">
            <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1>Popular Procedures</h1>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 text-center">
                            <p>The basic spa treatments are massage, facial, body treatment, manicure, and pedicure. A massage will help you relax and get rid of muscle tension. (A Swedish massage is a good place for beginners.) A facial is a deep cleansing of your face, and a body treatment exfoliates and softens the skin on your body.</p>
                        </div>
                    </div>
                    <div class="row features">
                        <div class="col-lg-4 text-center">
                            <div class="box">
                                <img src="images/massage_therapy.jpg" alt="Massage Therapy" height="230" width="280">
                                <h2>Massage Therapy</h2>
                                <p>Massage is delivered to improve the flow of blood and lymph (fluid in lymph glands, part of immune system), to reduce muscular tension or flaccidity, to affect the nervous system through stimulation or sedation, and to enhance tissue healing.</p>
                                <a href="service.php"><button type="button">READ MORE</button></a>
                            </div>
                        </div>
                        <div class="col-lg-4 text-center">
                            <div class="box">
                                <img src="images/beauty_care.jpg" alt="Beauty Care" height="230" width="280">
                                <h2>Beauty Care</h2>
                                <p>Beaty care is delivered to improve the flow of blood and lymph (fluid in lymph glands, part of immune system), to reduce muscular tension or flaccidity, to affect the nervous system through stimulation or sedation, and to enhance tissue healing.</p>
                                <a href="service.php"><button type="button">READ MORE</button></a>
                            </div>
                        </div>
                        <div class="col-lg-4 text-center">
                            <div class="box">
                                <img src="images/reflexology.jpg" alt="Reflexology" height="230" width="280">
                                <h2>Executive Reflexology</h2>
                                <p>Reflexology is delivered to improve the flow of blood and lymph (fluid in lymph glands, part of immune system), to reduce muscular tension or flaccidity, to affect the nervous system through stimulation or sedation, and to enhance tissue healing.</p>
                                <a href="service.php"><button type="button">READ MORE</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
<?php
    require __DIR__ . '../app/appServices.php';
?>  
            
            
            <div class="appointment">
                <div id="appPic">
                    <img src="images/appointment.jpg" alt="Appointment" height="500" width="545">
                </div>
                <div class="appointmentForm">
                        <form id="appforma" action="service.php" method="post">
                            <div class="twoColumns">
                                <div class="one">
                                    <p><input type="text" name="name" placeholder="NAME" required></p>
                                    <p><select id="serviceSelect">
                                        <option value="mainService">SELECT SERVICE</option>
                                        <option value="firstService">Service1</option>
                                        <option value="secondService">Service2</option>
                                        <option value="thirdService">Service3</option>
                                    </select></p>
                                    <p><input type="date" name="date" required></p>
                                </div>
                                <div class="two">
                                    <p><input type="email" name="email" placeholder="EMAIL ADDRESS" required></p>
                                    <p><input type="text" name="phone" placeholder="PHONE NUMBER" required></p>
                                    <p><input type="time" name="time" required></p>
                                </div>
                            </div>
                            <div class="notes">
                                <p><textarea placeholder="YOUR NOTES" name="message"></textarea></p>
                                <p><button name="submit" type="submit" id="appointment-submit">MAKE AN APPOINTMENT</button></p>
                            </div>
                        </form> 
                </div>
            </div>
            
            
            <div class="footer">
                <div class="logo-footer">
                    <a href="index.php"><img src="images/main_logo.png" alt="Logo of Leospa" width="50" height="40"></a>
                </div>
                <div class="logo-title"><a href="index.php">Leospa</a></div> 
                <div class="footer-navigation">
                    <div class="home"><a href="index.php">HOME</a></div>
                    <div class="about"><a href="about.php">ABOUT</a></div>
                    <div class="feature"><a href="features.php">FEATURE</a></div>
                    <div class="service"><a href="service.php">SERVICE</a></div>
                    <div class="contact"><a href="contact.php">CONTACT</a></div>
                </div>
                <div class="social-networks">
                    <a href="#top"><i class="fab fa-facebook-f"></i></a>&#124;
                    <a href="#top"><i class="fab fa-twitter"></i></a>&#124;
                    <a href="#top"><i class="fab fa-vimeo-v"></i></a>&#124;
                    <a href="#top"><i class="fab fa-instagram"></i></a>&#124;
                </div>
                <div id="copyright">
                    <?= '&copy; COPYRIGHT ' .date('Y'). ' ' .'THEMEIES.COM. ALL RIGHTS RESERVED.'; ?>
                </div>
            </div>
        </main>
    <script src="JS/jquery-3.2.1.min.js"></script>
    <script src="bootstrap-4.4.1-dist/js/bootstrap.js"></script>
    <script src="JS/custom.js"></script>
    </body>
</html>